/*************************************************************************************
Decription: This program utilizes linked lists to keep an ordered list of numbers.
            The program allows the user to do a few functions to edit and view
            the list


Author: Justin Ackley
Assignment: A02
Class: COMSC-110
Date: 08/30/2024
Status: Complete

************************************************************************************/


#include <iostream>
using namespace std;

int main() {
	cout << "Full credit please :3" << endl; // prints !!!Hello World!!!
	return 0;
}
